import random
from Clases.boleto import Boleto, Boleto_general, Boleto_vip
from Clases.cliente import Cliente
from Clases.equipo import Equipo
from Clases.estadio import Estadio
from Clases.partido import Partido
import Funciones.mostrar_partidos as mostrar_partidos
import Funciones.mostrar_asientos as mostrar_asientos
import archivo_json

def inicio_sesion(clientes: list[Cliente], partidos: list[Partido], equipos: list[Equipo], estadios: list[Estadio], boletos: list[Boleto]):
    while True:
        nuevo_usuario = es_nuevo_usuario()
        if nuevo_usuario is None:
            break

        if nuevo_usuario:
            nombre = preguntar("Ingrese nombre: ")
            ci = preguntar_numero("Ingrese ci: ")
            contrasena = preguntar("Ingrese su clave: ")
            age = preguntar_numero("Ingrese edad: ")
            for cliente in clientes:
                if cliente.ci == ci:
                    print("Ya existe un usuario con esa cedula")
                    continue
            nuevo_cliente = Cliente(nombre, age, ci, contrasena)
            clientes.append(nuevo_cliente)
        else:
            nuevo_cliente = iniciar_sesion(clientes)

        if nuevo_cliente:
            partido_seleccionado = preguntar_partido_especifico(partidos, equipos)
            es_vip = preguntar_tipo_entrada()

            asiento_seleccionado = preguntar_asientos(estadios,partido_seleccionado,es_vip,boletos)

            if es_vip:
                precio = nuevo_cliente.imprimir_precio(75)
            else:
                precio = nuevo_cliente.imprimir_precio(35)
            
            quiere_comprarlo = nuevo_cliente.quiere_comprarlo()

            if not quiere_comprarlo:
                seguir = quiere_seguir()
                if seguir:
                    continue
                else:
                    break
            
            if es_vip:
                boleto = Boleto_vip(generar_id(boletos),asiento_seleccionado,nuevo_cliente.ci,partido_seleccionado)
            else:
                boleto = Boleto_general(generar_id(boletos),asiento_seleccionado,nuevo_cliente.ci,partido_seleccionado)
            
            boleto.precio = precio
            boletos.append(boleto)
            print(f"asiento {str(asiento_seleccionado)} comprado exitosamente")
            print(f"El codigo unico de su boleto es {boleto.id}")
            archivo_json.escribir_en_json(equipos,partidos,estadios,clientes,boletos)

def generar_id(boletos: list[Boleto]):
    
    while True:
        id = random.randint(10000, 99999)
        se_repite = False
        for boleto in boletos:
            if boleto.id == id:
                se_repite = True
        
        if not se_repite:
            return id

def preguntar_asientos(estadios,partido_seleccionado,es_vip,boletos):
    while True:
        try:
            print("Elije uno: ")
            asientos = mostrar_asientos.mostrar_asientos(estadios,partido_seleccionado,es_vip,boletos)
            asiento = int(input("> "))

            if asiento in asientos:
                return asiento
            print("Asiento inválido")
        except Exception as e:
            print(e)


def preguntar_tipo_entrada():
    while True:
        try:
            pregunta = input("Es vip? (s o n): ")
            if pregunta.lower() == "s": return True
            if pregunta.lower() == "n": return False
        except:
            pass



def preguntar_partido_especifico(partidos, equipos):
    while True:
        try:
            print("Elige el partido que desees comprar sus entradas:")
            mostrar_partidos.mostrar_partidos_con_indice(partidos, equipos)
            pregunta = int(input("> "))
            partido_seleccionado = partidos[pregunta - 1]
            return partido_seleccionado
        except Exception as e:
            pass


def iniciar_sesion(clientes: list[Cliente]):
    while True:
        try:
            cedula = int(input("ingrese cedula: "))
            password = input("ingrese su clave: ")

            for cliente in clientes:
                if cliente.ci == cedula and cliente.password == password:
                    return cliente
            print("Ese cliente no existe")
            continuar = input("¿Volver a intentar? (s or n):")
            if continuar == "n":
                return False
        except:
            pass


def preguntar(mensaje: str):
    while True:
        try:
            pregunta = input(mensaje)

            if pregunta == "":
                continue

            return pregunta
        except:
            pass

def preguntar_numero(mensaje: str):
    while True:
        try:
            pregunta = int(input(mensaje))
            return pregunta
        except:
            pass



def es_nuevo_usuario():
    while True:
        pregunta = input('''ingrese opcion: 
1.- Iniciar sesión
2.- Registrarme
3.- Volver
> ''')
        if pregunta == '1':
            return False
        elif pregunta == "2":
            return True
        elif pregunta == "3":
            return None
        

def quiere_seguir():
    while True:
        seguir = input('''continuará?
1. Si
2. No
> ''') 
        if seguir == "1":
            return True
        if seguir == "2":
            return False