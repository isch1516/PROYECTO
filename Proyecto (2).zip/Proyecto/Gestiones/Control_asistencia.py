
from Clases.boleto import Boleto


def asistencia_al_partido(boletos: list[Boleto]):
    while True:
        try:
            boleto = preguntar_id_boleto(boletos)
            if boleto is None:
                break

            print(f"Su asistencia al partido {boleto.partido.number} a sido confirmada ")
            break
        except:
            print("Ha ocurrido un error")

def preguntar_id_boleto(boletos: list[Boleto]):
    while True:
        try:
            id = int(input("Ingrese id de su entrada: "))
            for boleto in boletos:
                if id == boleto.id and not boleto.asistio:
                    boletos.remove(boleto)
                    boleto.asistio = True
                    boletos.append(boleto)
                    return boleto
            
            probar_otra_vez=input('''entrada no encontrada o ya usada ¿Probaras con otro id?
1.- Si
2.- No
> ''')
            if probar_otra_vez == "2":
                return None

        except:
            print("error")