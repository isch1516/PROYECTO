from Clases.equipo import Equipo
from Clases.estadio import Estadio
from Clases.partido import Partido
import Funciones.mostrar_paises as mostrar_paises
import Funciones.mostrar_partidos as mostrar_partidos
import Funciones.mostrar_estadios as mostrar_estadios
import Funciones.mostrar_fechas as mostrar_fechas

def buscar_partidos(partidos: list[Partido], equipos: list[Equipo], estadio: list[Estadio]):

    while True:
        try:
            opcion = input('''¿Como desea buscar los partidos?
1. Buscar todos los partidos de un país
2. Buscar todos los partidos que se jugarán en un estadio específico
3. Buscar todos los partidos que se jugarán en una fecha determinada
4. Deseo volver
> ''')
            if opcion.lower() == "1":
                buscar_partidos_de_un_pais(partidos, equipos)
            elif opcion.lower() == "2":
                buscar_partidos_de_un_estadio(partidos,equipos,estadio)
            elif opcion.lower() == "3":
                buscar_partidos_de_una_fecha(partidos,equipos)
            elif opcion.lower() == "4":
                break
        except:
            pass

def buscar_partidos_de_un_pais(partidos: list[Partido], equipos: list[Equipo]):
    while True:
        try:
            print("Elige el pais del cual desees saber sus partidos")
            mostrar_paises.mostrar_todos_los_paises_con_indices(partidos, equipos)
            pregunta = int(input("> "))

            id_pais_seleccionado = partidos[pregunta -1].home

            partidos_filtrados = []
            for partido in partidos:
                if partido.home == id_pais_seleccionado:
                    partidos_filtrados.append(partido)
                
                if partido.away == id_pais_seleccionado:
                    partidos_filtrados.append(partido)
            
            print("Estos son los partidos que jugara el pais seleccionado:")
            mostrar_partidos.mostrar_partidos(partidos_filtrados, equipos)
            break
        except Exception as e:
            print(e)

def buscar_partidos_de_un_estadio(partidos: list[Partido], equipos: list[Equipo], estadios: list[Estadio]):
    while True:
        try:
            print("ingrese un estadio")
            mostrar_estadios.mostrar_todos_los_estadios_con_indices(estadios)
            pregunta = int(input("> "))

            estadio = estadios[pregunta - 1]
            partidos_filtrados = []
            for partido in partidos:
                if partido.stadium_id == estadio.id:
                    partidos_filtrados.append(partido)
            
            print("Estos son los partidos que se van a jugar en ese estadio")
            mostrar_partidos.mostrar_partidos(partidos, equipos)
            break
        except Exception as e:
            pass

def buscar_partidos_de_una_fecha(partidos: list[Partido], equipos: list[Equipo]):
    while True:
        try:
            print("Elija la fecha que desee ver los partidos")
            fechas = mostrar_fechas.mostrar_fechas_con_indices(partidos)
            pregunta = int(input("> "))
            
            fecha = fechas[pregunta - 1]
            partidos_filtrados = []
            for partido in partidos:
                if partido.date == fecha:
                    partidos_filtrados.append(partido)
            
            mostrar_partidos.mostrar_partidos(partidos_filtrados, equipos)
            break
        except:
            pass