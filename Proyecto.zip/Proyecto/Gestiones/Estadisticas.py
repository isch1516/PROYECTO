from Clases.boleto import Boleto, Boleto_vip
from Clases.cliente import Cliente
from Clases.equipo import Equipo
from Clases.estadio import Estadio
from Clases.partido import Partido
from Clases.restaurante import Restaurante
from Funciones import mostrar_partidos

def estadisticas(clientes: list[Cliente], boletos: list[Boleto], partidos: list[Partido], equipos: list[Equipo], estadios: list[Estadio]):
    while True:
        try:
            pregunta = input("""escoge una opcion: 
1.- promedio de gasto de un cliente VIP en un partido (ticket +
restaurante)
2.- tabla con la asistencia a los partidos de mejor a peor
3.- partido con mayor asistencia
4.- partido con mayor entradas vendidas
5.- Top 3 productos más vendidos en el restaurante.
6.- Top 3 de clientes
7.- Volver
> """)
            if pregunta == "1":
                partido = preguntar_partido_especifico(partidos, equipos)
                print(f"-----------> {promedio_gasto_cliente_productos_por_partido(clientes,partido) + promedio_gasto_cliente_vip_tickets_por_partido(boletos, partido)}")
            elif pregunta == "2":
                mostrar_tabla_mejor_a_peor(clientes, boletos, partidos, equipos)
            elif pregunta == "3":
                mostrar_partido_con_mayor_asistencia(clientes, boletos, partidos, equipos)
            elif pregunta == "4":
                mostrar_partido_con_mayor_venta(clientes, boletos, partidos, equipos)
            elif pregunta == "5":
                mostrar_tres_productos_mas_vendidos_por_restaurante(clientes, boletos, partidos, equipos, estadios)
            elif pregunta == "6":
                clientes_que_mas_compraron_boletos(clientes, boletos, partidos, equipos, estadios)
            elif pregunta == "7":
                break
        except Exception as e:
            print(e)

def preguntar_partido_especifico(partidos, equipos):
    while True:
        try:
            print("Elige el partido que desees:")
            mostrar_partidos.mostrar_partidos_con_indice(partidos, equipos)
            pregunta = int(input("> "))
            partido_seleccionado = partidos[pregunta - 1]
            return partido_seleccionado
        except Exception as e:
            print("error")
            pass

def promedio_gasto_cliente_vip_tickets(boletos: list[Boleto]):
    dinero = 0
    cantidad = 0
    for boleto in boletos:
        if isinstance(boleto, Boleto_vip):
            dinero += boleto.precio
            cantidad += 1
    return dinero / cantidad

def promedio_gasto_cliente_vip_tickets_por_partido(boletos: list[Boleto], partido: Partido):
    dinero = 0
    cantidad = 0
    for boleto in boletos:
        if isinstance(boleto, Boleto_vip) and boleto.cliente_ci == partido.id:
            dinero += boleto.precio
            cantidad += 1
    return dinero / cantidad if cantidad != 0 else 0

def promedio_gasto_cliente_productos_por_partido(clientes: list[Cliente], partido: Partido):
    dinero = 0
    cantidad = 0
    for cliente in clientes:
        for comprado in cliente.precios_productos_comprados:
            if comprado[4] == partido.id:
                dinero += comprado[3]
                cantidad += 1
    return dinero / cantidad if cantidad != 0 else 0

def mostrar_tabla_mejor_a_peor(clientes: list[Cliente], boletos: list[Boleto], partidos: list[Partido], equipos: list[Equipo]):
    lista_boletos_vendidos = []
    
    for boleto in boletos:
        if len(lista_boletos_vendidos) == 0:
            lista_boletos_vendidos.append([boleto.cliente_ci, 1])
        else:
            for indice in range(len(lista_boletos_vendidos)):
                if lista_boletos_vendidos[indice][0].id == boleto.cliente_ci:
                    lista_boletos_vendidos[indice][1] += 1
                    break
                elif indice == len(lista_boletos_vendidos) - 1:
                    lista_boletos_vendidos.append([boleto.cliente_ci, 1])
    
    lista_boletos_vendidos.sort(key=lambda x: x[1], reverse=True)
    
    for termino in lista_boletos_vendidos:
        print('--------------')
        partido = termino[0]
        partido: Partido
        print(partido.get_home(equipos), partido.get_away(equipos))
        asistidos = 0
        vendidos = 0
        for boleto in boletos:
            if boleto.cliente_ci.id == partido.id:
                print(boleto.cliente_ci)
                if boleto.asistio:
                    asistidos += 1
                    vendidos += 1
                else:
                    vendidos += 1
        print(f"asistidos: {asistidos}")
        print(f"vendidos: {vendidos}")

def mostrar_partido_con_mayor_asistencia(clientes, boletos, partidos, equipos):
    lista_boletos_asistidos = []
    
    for boleto in boletos:
        if len(lista_boletos_asistidos) == 0:
            lista_boletos_asistidos.append([boleto.partido, 1])
        else:
            for indice in range(len(lista_boletos_asistidos)):
                if lista_boletos_asistidos[indice][0].id == boleto.partido.id and boleto.asistio:
                    lista_boletos_asistidos[indice][1] += 1
                    break
                elif indice == len(lista_boletos_asistidos) - 1:
                    lista_boletos_asistidos.append([boleto.partido, 1])
    
    lista_boletos_asistidos.sort(key=lambda x: x[1], reverse=True)

    
    partido = lista_boletos_asistidos[0][0]
    print(f"Partido {partido.get_home(equipos)} - {partido.get_away(equipos)}: {lista_boletos_asistidos[0][1]} asistencias")
    
    pass

def mostrar_partido_con_mayor_venta(clientes, boletos, partidos, equipos):
    lista_boletos_vendidos = []
    
    for boleto in boletos:
        if len(lista_boletos_vendidos) == 0:
            lista_boletos_vendidos.append([boleto.partido, 1])
        else:
            for indice in range(len(lista_boletos_vendidos)):
                if lista_boletos_vendidos[indice][0].id == boleto.partido.id:
                    lista_boletos_vendidos[indice][1] += 1
                    break
                elif indice == len(lista_boletos_vendidos) - 1:
                    lista_boletos_vendidos.append([boleto.partido, 1])
    
    lista_boletos_vendidos.sort(key=lambda x: x[1], reverse=True)

    
    partido = lista_boletos_vendidos[0][0]
    print(f"Partido {partido.get_home(equipos)} - {partido.get_away(equipos)}: {lista_boletos_vendidos[0][1]} ventas")


    
    pass

def mostrar_tres_productos_mas_vendidos_por_restaurante(clientes, boletos, partidos, equipos, estadios):
    while True:
        try:
            estadios: list[Estadio]
            restaurantes = []
            restaurantes: list[Restaurante]
            for estadio in estadios:
                estadio: Estadio
                for restaurante in estadio.restaurantes:
                    restaurantes.append(restaurante)

            contador = 0
            for restaurante in restaurantes:
                print(str(contador),restaurante.name)
                contador += 1
            indice = int(input("Ingrese el restaurante que desee: "))

            rest = restaurantes[indice - 1]
            productos_del_restaurante = []
            for estadio in estadios:
                for restaurante in estadio.restaurantes:
                    for producto in restaurante.productos:
                        if rest.name == restaurante.name:
                            productos_del_restaurante.append(producto)
            # ............................


            lista_productos_vendidos = []
            
            for cliente in clientes:
                for producto_comprado in cliente.precios_productos_comprados:
                    if len(lista_productos_vendidos) == 0:
                        lista_productos_vendidos.append([producto_comprado[2], 1])
                    else:
                        for indice in range(len(lista_productos_vendidos)):
                            if lista_productos_vendidos[indice][0] == producto_comprado[2]:
                                lista_productos_vendidos[indice][1] += 1
                                break
                            elif indice == len(lista_productos_vendidos) - 1:
                                lista_productos_vendidos.append([producto_comprado[2], 1])
            
            lista_productos_vendidos.sort(key=lambda x: x[1], reverse=True)
            
            contador = 0
            print("\n\n******************")
            for termino in lista_productos_vendidos:
                producto = termino[0]
                print(f"Producto {producto}: {termino[1]} ventas")
                contador += 1
                if contador == 3:
                    break
            print("******************\n\n")
            break
        except:
            pass

def clientes_que_mas_compraron_boletos(clientes, boletos, partidos, equipos, estadios):
    lista_cantidad_compras_clientes = []
    
    for boleto in boletos:
        boleto: Boleto
        
        if len(lista_cantidad_compras_clientes) == 0:
            lista_cantidad_compras_clientes.append([boleto.cliente_ci, 1])
        else:
            for indice in range(len(lista_cantidad_compras_clientes)):
                if str(lista_cantidad_compras_clientes[indice][0]) == str(boleto.cliente_ci):
                    lista_cantidad_compras_clientes[indice][1] += 1
                    break
                elif indice == len(lista_cantidad_compras_clientes) - 1:
                    lista_cantidad_compras_clientes.append([boleto.cliente_ci, 1])
    
    lista_cantidad_compras_clientes.sort(key=lambda x: x[1], reverse=True)

    contador = 0
    for termino in lista_cantidad_compras_clientes:
        cliente = termino[0]
        print(f"Cedula {cliente}: {termino[1]} ventas")
        contador += 1
        if contador == 3: break
    