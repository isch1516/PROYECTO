
from Clases.boleto import Boleto
from Clases.cliente import Cliente
from Gestiones import buscar_partidos
import api
import archivo_json
from Gestiones import venta_entradas
from Gestiones import Ver_productos
from Gestiones import Control_asistencia
from Gestiones import Comprar_productos
from Gestiones import Estadisticas


def main():
    equipos, partidos, estadios, clientes, boletos = None,None,None,None,None 

    while True:
        pregunta = input("""reiniciar el programa
1.- Si
2.- No
> """)

        if pregunta == "1":
            equipos = api.crear_equipos()
            partidos = api.crear_partidos()
            estadios = api.crear_estadios()
            clientes = []
            clientes: list[Cliente]
            boletos = []
            boletos: list[Boleto]
            archivo_json.escribir_en_json(equipos,partidos,estadios, clientes, boletos)
            break
        elif pregunta == "2":
            equipos, partidos, estadios, clientes, boletos = archivo_json.leer_json()
            break
        
    while True:
        try:

            inicio = input('''elige una opcion: 
1.- Buscar partidos
2.- Comprar entradas
3.- Asistencia al partido
4.- Mostrar productos vip de los restaurantes de un partido
5.- Comprar producto
6.- Estadisticas
7.- Volver
> ''')
    
            if inicio == "1":
                buscar_partidos.buscar_partidos(partidos, equipos, estadios)
            elif inicio == "2":
                venta_entradas.inicio_sesion(clientes,partidos, equipos, estadios, boletos)
            elif inicio == "3":
                Control_asistencia.asistencia_al_partido(boletos)
            elif inicio == "4":
                Ver_productos.show_productos(partidos,equipos, estadios)
            elif inicio == "5":
                Comprar_productos.comprar_producto(estadios, boletos, clientes,partidos, equipos)
            elif inicio == "6":
                Estadisticas.estadisticas(clientes,boletos,partidos,equipos, estadios)
            elif inicio == "7":
                break
        

            archivo_json.escribir_en_json(equipos,partidos,estadios, clientes, boletos)
        except Exception as e:
            print(e)

main()